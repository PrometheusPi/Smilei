#include "Projector1D.h"

#include "Params.h"
#include "Patch.h"

Projector1D::Projector1D( Params &params, Patch *patch )
    : Projector( params, patch )
{
}

