#ifndef userFunctions_h
#define userFunctions


double u_InitTemperature(double x, double y, double z);

#endif

